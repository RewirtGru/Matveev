<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная - Магазин электроники</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">NE DNS</div>
            <ul>
                <li><a href="index.php">Главная</a></li>
                <li><a href="catalog.php">Каталог</a></li>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <li><a href="logout.php">Выйти (<?php echo $_SESSION['username']; ?>)</a></li>
                <?php else: ?>
                    <li><a href="login.php">Войти</a></li>
                    <li><a href="register.php">Регистрация</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <main>
        <section class="hero">
            <h1>Добро пожаловать в TechShop</h1>
            <p>Лучшие смартфоны по доступным ценам</p>
            <?php if(!isset($_SESSION['user_id'])): ?>
                <a href="register.php" class="btn">Начать покупки</a>
            <?php else: ?>
                <a href="catalog.php" class="btn">Перейти в каталог</a>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 NE DNS. Все права защищены.</p>
    </footer>
</body>
</html>