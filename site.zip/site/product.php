<?php
include 'config.php';

if(!isset($_GET['id'])) {
    header("Location: catalog.php");
    exit;
}

$product_id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if(!$product) {
    header("Location: catalog.php");
    exit;
}

if(isset($_POST['add_comment']) && isset($_SESSION['user_id'])) {
    $comment = $_POST['comment']; 
    
    if(!empty($comment)) {
        $stmt = $pdo->prepare("INSERT INTO comments (product_id, user_id, comment) VALUES (?, ?, ?)");
        $stmt->execute([$product_id, $_SESSION['user_id'], $comment]);
        header("Location: product.php?id=" . $product_id);
        exit;
    }
}

$stmt = $pdo->prepare("
    SELECT c.*, u.username 
    FROM comments c 
    JOIN users u ON c.user_id = u.id 
    WHERE c.product_id = ? 
    ORDER BY c.created_at DESC
");
$stmt->execute([$product_id]);
$comments = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $product['name']; ?> - TechShop</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">TechShop</div>
            <ul>
                <li><a href="index.php">Главная</a></li>
                <li><a href="catalog.php">Каталог</a></li>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <li><a href="logout.php">Выйти (<?php echo $_SESSION['username']; ?>)</a></li>
                <?php else: ?>
                    <li><a href="login.php">Войти</a></li>
                    <li><a href="register.php">Регистрация</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <main>
        <section class="product-detail">
            <div class="product-header">
                <div class="product-image">
                    <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" onerror="this.src='placeholder.jpg'">
                </div>
                <div class="product-info">
                    <h1><?php echo $product['name']; ?></h1>
                    <p class="price">$<?php echo $product['price']; ?></p>
                    <p class="description"><?php echo $product['description']; ?></p>
                </div>
            </div>

            <div class="comments-section">
                <h2>Комментарии</h2>
                
                <?php if(isset($_SESSION['user_id'])): ?>
                    <form method="POST" class="comment-form">
                        <textarea name="comment" placeholder="Оставьте ваш комментарий..." required></textarea>
                        <button type="submit" name="add_comment" class="btn">Добавить комментарий</button>
                    </form>
                <?php else: ?>
                    <p>Пожалуйста, <a href="login.php">войдите</a>, чтобы оставить комментарий.</p>
                <?php endif; ?>

                <div class="comments-list">
                    <?php if(empty($comments)): ?>
                        <p>Пока нет комментариев. Будьте первым!</p>
                    <?php else: ?>
                        <?php foreach($comments as $comment): ?>
                            <div class="comment">
                                <div class="comment-header">
                                    <strong><?php echo $comment['username']; ?></strong> 
                                    <span class="comment-date"><?php echo date('d.m.Y H:i', strtotime($comment['created_at'])); ?></span>
                                </div>
                                <div class="comment-text">
                                    <?php echo $comment['comment']; ?> 
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 TechShop. Все права защищены.</p>
    </footer>
</body>
</html>